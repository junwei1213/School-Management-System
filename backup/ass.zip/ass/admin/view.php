<?php
include ('../config.php');
include('../libs/phpqrcode/qrlib.php');
session_start();
if(!isset($_COOKIE['UNAME'])){
	header('location:login.php');
	die();
}
$adminid=$_COOKIE['UNAME'];

?>

<!DOCTYPE html>
<html>
	<head>
	<title>QR code genaral</title>
    <link rel="stylesheet" href="libs/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../libs/style.css">
	<link rel="stylesheet" type="text/css" href="../css/util.css">
	<link rel="stylesheet" type="text/css" href="../css/main.css">
    </head>
	<body>
	
<?php
		$sqlselect = "SELECT * FROM class_list WHERE adminid ='".$adminid."'";
		if($result = mysqli_query($conn,$sqlselect)){
		if(mysqli_num_rows($result)>0){
			echo "<form  method=get>";
			echo "<div class=container-table100>";
			echo "<div class=wrap-table100>";
			echo "<div class=table100>";
			echo "<a href=index.php class=text1>Back To Home Oage</a>";
			echo "<a href=insert.php class=text1>Create Class</a>";
			echo "<table>";
			echo "<thead>";	
				echo "<tr class=table100-head>";
					echo "<th class=column1>Subject</th>";
					echo "<th class=column2>Class</th>";
					echo "<th class=column3>Description</th>";
					echo "<th class=column4>Vaveu</th>";
					
					echo "<th class=column5>Date Time Start</th>";
					echo "<th class=column6>Date Time End</th>";
					
					
					echo "<th class=column7>QR Code</th>";
					
					
					
					
				echo "</tr>";
				echo "</thead>";	
			while($data = mysqli_fetch_assoc($result)){
				echo "<tbody>";
				echo "<tr>";
					echo "<td class=column1>".$data['subjectid']."</td>";
					echo "<td class=column2>".$data['class']."</td>";
					echo "<td class=column3>".$data['description']."</td>";
					echo "<td class=column4>".$data['venue']."</td>";
					
					echo "<td class=column5>".$data['datetime_start']."</td>";
					echo "<td class=column6>".$data['datetime_end']."</td>";
					
					echo "<td class=column7><img src=".$data['qrcode']." style=width:128px;height:128px ></td>";
					
					}
					
				
				echo "</tr>";
				echo "</tbody>";
			echo "</table>";
			echo "</div>";
			echo "</div>";
		echo "</div>";
			echo "</form>";
			
			mysqli_free_result($result);
		}else{
			echo "<a href=insert.php class=text1>Create Class</a><br>";
			echo "No record";
		}
		
	
}else{
	echo "ERROR: $sqlselect.".mysqli_error($conn);
}
?>
</body>
</html>