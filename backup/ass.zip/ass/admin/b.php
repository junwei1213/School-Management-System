<?php

include('../config.php');
if(isset($_POST['submit'])){
	$subject = $_POST['subject'];
		$class = $_POST['class'];
$sqlstuednt = "SELECT studentid FROM student WHERE subjectid='".$subject."'";
			
			
			$resultstudenid = mysqli_query($conn,$sqlstuednt);
			for($i=0;$array[$i]=mysqli_fetch_assoc($resultstudenid);$i++);
			
			echo array_pop($array);
			 
			
			}
			
				
			
	
	
	
	
	/**/

?>
<!DOCTYPE html>
<html>
	<head>
	<title>QR code genaral</title>
    <link rel="stylesheet" href="../libs/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../libs/style.css">
    </head>
	<body>
	

			<h3><strong>QR code</strong></h3>
			<div class="input-field">
				<h3>New Class</h3>
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
					<div class="form-group">
						
							<?php
					
						$sql="SELECT subjectid FROM subject ";
						$result=mysqli_query($conn,$sql);
							if($result !== 0){
							echo "<label>Assign To</label><br />";
							echo '<td><select name="subject">';
							echo '<option value=""></option>';
							$num_results = mysqli_num_rows($result);
								for ($i=0;$i<$num_results;$i++) {
								$row=mysqli_fetch_array($result);
								$subjectcode = $row['subjectid'];
								
								echo '<option value="'.$subjectcode .'">'.$subjectcode.'</option>';
								}
							echo "</select>";
		
								}
							mysqli_close($conn);
						?>
					</div>
					<div class="form-group">
						<label>Class</label><br/>
						<select name="class">;
						<option value="Class1">Class1</option>
						<option value="Class2">Class2</option>
						<option value="Class3">Class3</option>
						<option value="Class4">Class4</option>
						<option value="Class5">Class5</option>
						<option value="Class6">Class6</option>
						<option value="Class7">Class7</option>
						<option value="Class8">Class8</option>
						<option value="Class9">Class9</option>
						<option value="Class10">Class10</option>
						</select>
					</div>
					<div class="form-group">
						<input type="submit" name="submit" class="btn btn-danger submitBtn" style="width:20em; margin:0;" />
					</div>
					
					
				</form>
			</div>
			
			
	
	</body>

</html>