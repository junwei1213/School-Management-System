<?php
include('../config.php');
	
if(isset ($_POST['submit'])){
	$userid = $_POST['userid'];
	$username=$_POST['username'];
	$address = $_POST['address'];
	$subject = $_POST['subject'];
	$passwordhash=$_POST['password'];
	$phone=$_POST['phone'];
	
	$useridcheck=mysqli_query($conn,"SELECT studentid FROM student WHERE studentid='$userid'");
	$count=mysqli_num_rows($useridcheck);
		if($count>=1){
			echo "<center><h2>".$userid." is already taken</h2></center><br>";
		}
		else
		{
		$hashed_password=hash('sha1',$passwordhash);
		$query= "insert into student(studentid,studentname,address,phone,subjectid,password) 
		values('$userid','$username','$address','$phone','$subject','$hashed_password')";
		$run= mysqli_query($conn,$query) or die(mysqli_error());
	
			if($run){
				echo "<center><h2>Userdata submittion successfully</h2></center>";

			}else{
				echo "<center><h2>Userdata submittion failed</h2></center>";
			}
		}
		
	}
?>


<html>
<head>

	<title>Register Form</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>

<body>
 <img class="wave" src="../img/wave.png">
	<div class="container">
		<div class="img">
			<img src="../img/bg.svg">
		</div>
		<div class="login-content"> 
	<form action="register.php" method="post">
		<img src="../img/avatar.svg">
	<h2 class="title">Register here!</h2>
	<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		
						<input type="text" name="userid" placeholder="Userid" id="userid" class="input" required>           		   </div>
           		</div>
	<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		
						<input type="text" name="username" placeholder="Username" id="username" class="input" required>           		   </div>
           		</div>
	<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	
						<input type="password" name="password" placeholder="Password" class="input" required><br>		
            	   </div>
            	</div>
				
				<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-phone"></i>
           		   </div>
           		   <div class="div">
           		    	
				<input type="text" name="address" placeholder="Address" class="input" required><br><br>            	   </div>
            	</div>
				
				<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-phone"></i>
           		   </div>
           		   <div class="div">
           		    	
				<input type="text" name="phone" placeholder="Phone" class="input" required><br><br>            	   </div>
            	</div>
				
				<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-phone"></i>
           		   </div>
           		   <div class="div">
           		    	
						<?php
							$sqlsubject = "SELECT subjectid FROM subject";
							$result=mysqli_query($conn,$sqlsubject);
							echo '<select name="subject">';
							echo '<option value=""></option>';
							$num_results = mysqli_num_rows($result);
								for ($i=0;$i<$num_results;$i++) {
								$row=mysqli_fetch_array($result);
								$subjectid = $row['subjectid'];
								
								echo '<option value="'.$subjectid .'">'.$subjectid.'</option>';
								}
							echo "</select>";
						
						?>
				</div>
            	</div>
				
				<button type="submit" name="submit" class="btn">Register</button><br> 
		<a href="login.php">Already have a account?</a>

		

		
		</form>
	</div>
	
	 </div>
    </div>
	
</body>
</html>

